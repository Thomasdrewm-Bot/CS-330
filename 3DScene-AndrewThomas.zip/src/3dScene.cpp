#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "meshes.h"
#include "camera.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Andrew Thomas"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Shader program
    GLuint gProgramId;
    // Object with all of the meshes
    Meshes meshes;
    // Texture ids
    GLuint planeTexture, legoBrickTexture, legoConnectorTexture, diceBoxTexture;
    glm::vec2 gUVScale(2.0f, 2.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Camera variables
    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    float cameraSpeed = 2.5f;

    // Creates a projection, creates bool to show it is currently perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    bool gPerspective = true;

    // Time between current and last frames.
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Lighting Variables
    GLint viewPosLoc;
    GLint ambStrLoc;
    GLint ambColLoc;
    GLint light1ColLoc;
    GLint light1PosLoc;
    GLint light2ColLoc;
    GLint light2PosLoc;
    GLint specInt1Loc;
    GLint highlghtSz1Loc;
    GLint specInt2Loc;
    GLint highlghtSz2Loc;
    GLint uHasTextureLoc;
    bool ubHasTextureVal;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void UMousePositionCallback(GLFWwindow* gWindow, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* gWindow, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* gWindow, int button, int action, int mods);
bool UCreateTextures();
void UDestroyTexture(GLuint textureId);

// Creation of object methods
void UCreatePlane(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc);
void UCreateLegoBrick(glm::mat4 &scale, glm::mat4 &rotation, glm::mat4 &translation, glm::mat4 &model, GLint &modelLoc, GLint &objectColorLoc);
void UCreateGameBox(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc);
void UCreateGlassesCleaner(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc);
void UCreateDiceCase(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
layout(location = 1) in vec3 normal; // Vertex data for normals
layout(location = 2) in vec2 textureCoordinates;  // sets the texture coordinates based on mesh

out vec3 vertexFragmentNormal; // For outgoing normals to the fragment shader
out vec3 vertexFragmentPos; // for outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate; // variable to transfer color data to the fragment shader

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only

    vertexFragmentNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties.
    vertexTextureCoordinate = textureCoordinates; // references the textures coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate; // Variable to hold incoming color data from vertex shader
in vec3 vertexFragmentNormal; // For incoming normals
in vec3 vertexFragmentPos; // for incoming fragment position


out vec4 fragmentColor; // declares variable that will be put out by fragment shader

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec4 objectColor;
uniform vec3 ambientColor;
uniform vec3 light1Color;
uniform vec3 light1Position;
uniform vec3 light2Color;
uniform vec3 light2Position;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;
uniform bool ubHasTexture;
uniform float ambientStrength = 0.1f; // Set ambient or global lighting strength
uniform float specularIntensity1 = 0.8f;
uniform float highlightSize1 = 16.0f;
uniform float specularIntensity2 = 0.8f;
uniform float highlightSize2 = 16.0f;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    vec3 ambient = ambientStrength * ambientColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexFragmentNormal); // Normalize vectors to 1 unit
    vec3 light1Direction = normalize(light1Position - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact1 = max(dot(norm, light1Direction), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse1 = impact1 * light1Color; // Generate diffuse light color
    vec3 light2Direction = normalize(light2Position - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact2 = max(dot(norm, light2Direction), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse2 = impact2 * light2Color; // Generate diffuse light color

    //**Calculate Specular lighting**
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir1 = reflect(-light1Direction, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent1 = pow(max(dot(viewDir, reflectDir1), 0.0), highlightSize1);
    vec3 specular1 = specularIntensity1 * specularComponent1 * light1Color;
    vec3 reflectDir2 = reflect(-light2Direction, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize2);
    vec3 specular2 = specularIntensity2 * specularComponent2 * light2Color;

    //**Calculate phong result**
    //Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
    vec3 phong1;
    vec3 phong2;

    if (ubHasTexture == true) // In case we render an object without a texture we have both pieces of code.
    {
        phong1 = (ambient + diffuse1 + specular1) * textureColor.xyz;
        phong2 = (ambient + diffuse2 + specular2) * textureColor.xyz;
    }
    else
    {
        phong1 = (ambient + diffuse1 + specular1) * objectColor.xyz;
        phong2 = (ambient + diffuse2 + specular2) * objectColor.xyz;
    }

    fragmentColor = vec4(phong1 + phong2, 1.0); // Send lighting results to GPU
    //fragmentColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    meshes.CreateMeshes();

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Load multiple textures based on array of image addresses.
    if (!UCreateTextures())
        return EXIT_FAILURE;

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);

    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);
    glUniform2f(glGetUniformLocation(gProgramId, "uvScale"), gUVScale.x, gUVScale.y);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // Set the initial camera position
    gCamera.Position = glm::vec3(0.0f, 0.0f, 2.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // Per-frame timing for camera motion
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    meshes.DestroyMeshes();

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }

    // These set the windows settings to recognize these functions when appropriate callbacks are triggered.
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);    

    // determines how fast the camera moves based on the speed variable and the elapsed time
    float cameraOffset = cameraSpeed * gDeltaTime;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    // Changes to perspective projection on P key press
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        if (!(gPerspective))
        {
            projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
            gPerspective = true;
        }

    }

    // Changes to ortho projection on O key press
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
    {
        if (gPerspective)
        {
            projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
            glm::vec3 target = glm::vec3(0.0f, 0.0f, 0.0f);
            gCamera.Position = glm::vec3(0.0f, 0.0f, 5.0f);
            gCamera.Up = glm::vec3(0.0f, 1.0f, 0.0f);
            gCamera.Front = glm::normalize(gCamera.Position - target);
            gPerspective = false;
        }
    }
    
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// Functioned called to render a frame
void URender()
{
    // Declaring variables for model and camera movement
    glm::mat4 scale;
    glm::mat4 rotation;
    glm::mat4 translation;
    glm::mat4 model;
    glm::mat4 view = gCamera.GetViewMatrix();
    GLint modelLoc;
    GLint viewLoc;
    GLint projLoc;
    GLint objectColorLoc;
    

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    ambStrLoc = glGetUniformLocation(gProgramId, "ambientStrength");
    ambColLoc = glGetUniformLocation(gProgramId, "ambientColor");
    light1ColLoc = glGetUniformLocation(gProgramId, "light1Color");
    light1PosLoc = glGetUniformLocation(gProgramId, "light1Position");
    light2ColLoc = glGetUniformLocation(gProgramId, "light2Color");
    light2PosLoc = glGetUniformLocation(gProgramId, "light2Position");
    specInt1Loc = glGetUniformLocation(gProgramId, "specularIntensity1");
    highlghtSz1Loc = glGetUniformLocation(gProgramId, "highlightSize1");
    specInt2Loc = glGetUniformLocation(gProgramId, "specularIntensity2");
    highlghtSz2Loc = glGetUniformLocation(gProgramId, "highlightSize2");
    uHasTextureLoc = glGetUniformLocation(gProgramId, "ubHasTexture");

    // Sets the projection and view values for the uniforms.
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    //set the camera view location
    glUniform3f(viewPosLoc, gCamera.Position.x, gCamera.Position.y, gCamera.Position.z);
    
    // Verifies that the texture has a location so it processes the if statement correctly for textured objects
    ubHasTextureVal = true;
    glUniform1i(uHasTextureLoc, ubHasTextureVal);

    // Calls functions to draw each object in 3d scene.
    UCreatePlane(scale, rotation, translation, model, modelLoc, objectColorLoc);
    UCreateLegoBrick(scale, rotation, translation, model, modelLoc, objectColorLoc);
    UCreateDiceCase(scale, rotation, translation, model, modelLoc, objectColorLoc);

    // Verifies that the texture has a location so it processes the if statement correctly for non-textured object
    ubHasTextureVal = false;
    glUniform1i(uHasTextureLoc, ubHasTextureVal);

    UCreateGameBox(scale, rotation, translation, model, modelLoc, objectColorLoc);
    
    UCreateGlassesCleaner(scale, rotation, translation, model, modelLoc, objectColorLoc);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

// Calls this whenever the mouse is moved.
void UMousePositionCallback(GLFWwindow* gWindow, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed to accommodate for y-coordinates going from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// Calls this whenever the mouse scroll wheel scrolls.
void UMouseScrollCallback(GLFWwindow* gWindow, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

void UMouseButtonCallback(GLFWwindow* gWindow, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
        
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


/*
* This will load all of the textures into the GPU
*/
bool UCreateTextures()
{
    int width, height, channels;

    // File paths for all of the textures
    string texFilePath[4] = 
    { 
        "resources/textures/woodtable.jpg",     // 0 index 
        "resources/textures/legobrick.jpg",     // 1 index
        "resources/textures/legoconnector.jpg", // 2 index
        "resources/textures/dicebox.png"        // 3 index
    };


    // Load Plane Texture
    unsigned char* image = stbi_load(texFilePath[0].c_str(), &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &planeTexture);
        glBindTexture(GL_TEXTURE_2D, planeTexture);

        // Set the texture wrapping parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        // Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
    }
    else
    {
        cout << "Failed to load texture " << texFilePath[0] << endl;
        return false;
    }

    // Load Lego Brick Texture
    image = stbi_load(texFilePath[1].c_str(), &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &legoBrickTexture);
        glBindTexture(GL_TEXTURE_2D, legoBrickTexture);

        // Set the texture wrapping parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
    }
    else
    {
        cout << "Failed to load texture " << texFilePath[1] << endl;
        return false;
    }

    // Load Lego Brick Connector texture
    image = stbi_load(texFilePath[2].c_str(), &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &legoConnectorTexture);
        glBindTexture(GL_TEXTURE_2D, legoConnectorTexture);

        // Set the texture wrapping parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        // Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
    }
    else
    {
        cout << "Failed to load texture " << texFilePath[2] << endl;
        return false;
    }

    // Load Dice Box Texture
    image = stbi_load(texFilePath[3].c_str(), &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &diceBoxTexture);
        glBindTexture(GL_TEXTURE_2D, diceBoxTexture);

        // Set the texture wrapping parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
    }
    else
    {
        cout << "Failed to load texture " << texFilePath[3] << endl;
        return false;
    }
}

void UDestroyTexture(GLuint textureId)
{

}

void UCreatePlane(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc)
{
    // Sets lighting for object
    //set ambient lighting strength
    glUniform1f(ambStrLoc, 0.4f);
    //set ambient color
    glUniform3f(ambColLoc, 0.1f, 0.1f, 0.1f);
    glUniform3f(light1ColLoc, 0.3f, 0.2f, 0.95f);
    glUniform3f(light1PosLoc, -10.0f, 8.0f, -0.5f);
    glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light2PosLoc, 10.0f, 10.0f, 0.5f);
    //set specular intensity
    glUniform1f(specInt1Loc, 0.6f);
    glUniform1f(specInt2Loc, 1.0f);
    //set specular highlight size
    glUniform1f(highlghtSz1Loc, 2.0f);
    glUniform1f(highlghtSz2Loc, 2.0f);


    // Activate the VBOs contained within the meshe's VAO for the plane
    glBindVertexArray(meshes.gPlaneMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(15.0f, 1.0f, 15.0f));
    // 2. Rotate the object
    rotation = glm::rotate(40.0f, glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(5.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, planeTexture);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
}

void UCreateLegoBrick(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc)
{
    // Sets lighting for object
    //set ambient lighting strength
    glUniform1f(ambStrLoc, 0.3f);
    //set ambient color
    glUniform3f(ambColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light1ColLoc, 0.3f, 0.2f, 0.95f);
    glUniform3f(light1PosLoc, 7.0f, 6.0f, 0.0f);
    glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light2PosLoc, -7.0f, 4.0f, 0.0f);
    //set specular intensity
    glUniform1f(specInt1Loc, 0.2f);
    glUniform1f(specInt2Loc, 8.0f);
    //set specular highlight size
    glUniform1f(highlghtSz1Loc, 2.0f);
    glUniform1f(highlghtSz2Loc, 2.0f);

    /*********** Lego Brick Box ***********/
    // Activate the VBOS in the meshes object
    glBindVertexArray(meshes.gBoxMesh.vao);

    // 1. Scales the Lego Brick cube
    scale = glm::scale(glm::vec3(5.0f, 1.5f, 2.5f));
    // 2. Rotate the Lego Brick cube
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    // 3. Position the Lego Brick cube
    translation = glm::translate(glm::vec3(0.0f, 0.75f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));  // Sets the uniform for the model to the shader code.

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, legoBrickTexture);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object for the lego brick box
    glBindVertexArray(0);

    /*********** Lego Torus Connecter 1 ***********/
    // Activates the VBOs in the meshes object for lego connector
    glBindVertexArray(meshes.gTorusMesh.vao);

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(-1.75f, 1.6f, -0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, legoConnectorTexture);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 2 ***********/

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(-0.63f, 1.6f, -0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 3 ***********/

    // 1. Scales the Lego Connector 3 Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(0.63f, 1.6f, -0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 4 ***********/

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(1.75f, 1.6f, -0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 5 ***********/

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(-1.75f, 1.6f, 0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 6 ***********/

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(-0.63f, 1.6f, 0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 7 ***********/

    // 1. Scales the Lego Connector 3 Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(0.63f, 1.6f, 0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    /*********** Lego Torus Connecter 8 ***********/

    // 1. Scales the Lego Connector Torus
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.0f));
    // 2. Rotate the Torus to the correct angle
    rotation = glm::rotate(1.55f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the Lego connector Torus in relation to the brick.
    translation = glm::translate(glm::vec3(1.75f, 1.6f, 0.5f));
    // Model matrix: Transformations applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Sets the uniform for the model to shader code

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

    // Deactivate Vertex array object for the lego connector torus
    glBindVertexArray(0);
}

void UCreateGameBox(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc)
{
    // Sets lighting for object
    //set ambient lighting strength
    glUniform1f(ambStrLoc, 0.7f);
    //set ambient color
    glUniform3f(ambColLoc, 0.7f, 0.7f, 0.7f);
    glUniform3f(light1ColLoc, 0.2f, 0.3f, 0.95f);
    glUniform3f(light1PosLoc, 7.5f, 0.5f, 0.0f);
    glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light2PosLoc, 5.0f, 8.0f, 0.0f);
    //set specular intensity
    glUniform1f(specInt1Loc, 0.4f);
    glUniform1f(specInt2Loc, 4.0f);
    //set specular highlight size
    glUniform1f(highlghtSz1Loc, 2.0f);
    glUniform1f(highlghtSz2Loc, 2.0f);

    // Activate the VBOS in the meshes object
    glBindVertexArray(meshes.gBoxMesh.vao);

    // 1. Scales the Lego Brick cube
    scale = glm::scale(glm::vec3(8.5f, 3.0f, 4.5f));
    // 2. Rotate the Lego Brick cube
    rotation = glm::rotate(45.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Position the Lego Brick cube
    translation = glm::translate(glm::vec3(5.0f, 1.5f, 3.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));  // Sets the uniform for the model to the shader code.

    glProgramUniform4f(gProgramId, objectColorLoc, 0.0f, 0.0f, 0.8f, 1.0f);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object for the lego brick box
    glBindVertexArray(0);
}

void UCreateGlassesCleaner(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc)
{
    // Sets lighting for object
    //set ambient lighting strength
    glUniform1f(ambStrLoc, 0.5f);
    //set ambient color
    glUniform3f(ambColLoc, 0.7f, 0.7f, 0.7f);
    glUniform3f(light1ColLoc, 0.2f, 0.3f, 0.95f);
    glUniform3f(light1PosLoc, 3.0f, 0.0f, -5.5f);
    glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light2PosLoc, 3.0f, 3.0f, -1.5f);
    //set specular intensity
    glUniform1f(specInt1Loc, 0.6f);
    glUniform1f(specInt2Loc, 2.8f);
    //set specular highlight size
    glUniform1f(highlghtSz1Loc, 2.0f);
    glUniform1f(highlghtSz2Loc, 2.0f);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.5f, 4.0f, 0.5f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(3.0f, 0.0f, -3.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glProgramUniform4f(gProgramId, objectColorLoc, 0.8f, 0.0f, 0.0f, 1.0f);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gTaperedCylinderMesh.vao);
}

void UCreateDiceCase(glm::mat4& scale, glm::mat4& rotation, glm::mat4& translation, glm::mat4& model, GLint& modelLoc, GLint& objectColorLoc)
{
    // Sets lighting for object
    //set ambient lighting strength
    glUniform1f(ambStrLoc, 0.4f);
    //set ambient color
    glUniform3f(ambColLoc, 0.1f, 0.1f, 0.1f);
    glUniform3f(light1ColLoc, 0.2f, 0.3f, 0.95f);
    glUniform3f(light1PosLoc, 6.0f, 4.0f, 0.0f);
    glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(light2PosLoc, 5.0f, 7.0f, 1.0f);
    //set specular intensity
    glUniform1f(specInt1Loc, 1.0f);
    glUniform1f(specInt2Loc, 4.0f);
    //set specular highlight size
    glUniform1f(highlghtSz1Loc, 2.0f);
    glUniform1f(highlghtSz2Loc, 2.0f);


    // Activate the VBOs contained within the meshe's VAO for the plane
    glBindVertexArray(meshes.gBoxMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(1.0f, 2.0f, 1.0f));
    // 2. Rotate the object
    rotation = glm::rotate(45.0f, glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(5.0f, 4.0f, 1.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));


    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, diceBoxTexture);

    // Set the color of the object.
    // glProgramUniform4f(gProgramId, objectColorLoc, 0.5f, 0.5f, 0.0f, 1.0f);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
}





